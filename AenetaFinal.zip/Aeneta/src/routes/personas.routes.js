import {Router} from 'express'
import pool from '../database.js'

const router = Router();

router.get('/add',(req, res)=> {
    res.render('personas/add');
});

router.get('/preguntasFrecuentesAdmin',(req, res)=> {
    res.render('personas/admin/preguntasFrecuentesAdmin');
});

router.get('/preguntasFrecuentesAlumno',(req, res)=> {
    res.render('personas/alumno/preguntasFrecuentesAlumno');
});

router.get('/preguntasFrecuentesDocente',(req, res)=> {
    res.render('personas/docente/preguntasFrecuentesDocente');
});
router.get('/edit/:id', async(req, res)=> {
    const { id } = req.params;
    try {
        const [result] = await pool.query('SELECT * FROM personas WHERE id = ?', [id]);
        if (result.length > 0) {
            console.log(result);
            res.render('personas/admin/edit', { personas: result });
        } else {
            res.status(404).send('Propuesta aceptada no encontrada.');
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
    
});

router.get('/delete/:id', async(req, res)=> {
    const { id } = req.params;
    try {
        const [result] = await pool.query('delete FROM personas WHERE id = ?', [id]);
        
        if (result.length > 0) {
            console.log(result);
            
        } else {
            const [updatedResult] = await pool.query('SELECT * FROM personas');
        res.render('personas/list', { personas: updatedResult });
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
    
});

router.post('/update/:id', async (req, res) => {
    const { id } = req.params;
    const { name, lastname, age, email, pass, tipo } = req.body;

    try {
        // Realizar la consulta de actualización
        const [result] = await pool.query(
            `UPDATE personas SET name = ?, lastname = ?, age = ?, email = ?, pass = ?, tipo = ? WHERE id = ?`,
            [name, lastname, age, email, pass, tipo, id]
        );

        // Verificar si se actualizó algún registro
        if (result.affectedRows > 0) {
            console.log(result);
            // Puedes realizar una consulta para obtener la lista actualizada de personas si lo necesitas
            const [updatedResult] = await pool.query('SELECT * FROM personas');
            res.render('personas/list', { personas: updatedResult });
        } else {
            res.status(404).send('Propuesta aceptada no encontrada.');
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.get('/asignarSinodal/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const [result] = await pool.query('SELECT * FROM propuestasAceptadas WHERE id = ?', [id]);
        if (result.length > 0) {
            console.log(result);
            res.render('personas/admin/asi', { propuestas: result });
        } else {
            res.status(404).send('Propuesta aceptada no encontrada.');
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.get('/asignarSinodal', async (req, res) => {
    const { id } = req.params;
    try {
        const [result] = await pool.query('SELECT * FROM propuestasAceptadas ');
        if (result.length > 0) {
            res.render('personas/admin/asignarSinodal', { propuestas: result });
        } else {
            res.status(404).send('Propuesta aceptada no encontrada.');
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.get('/evaluarTT/:id',async (req, res)=> {
    const { id } = req.params;
    try {
        const [result] = await pool.query('SELECT * FROM propuestasAceptadas where id = ?', [id]);
        if (result.length > 0) {
            res.render('personas/docente/evaluarTT', { propuestas: result });
        } else {
            res.status(404).send('Propuesta aceptada no encontrada.');
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});


router.get('/enviarPropuesta',(req, res)=> {
    res.render('personas/alumno/enviarPropuesta', {user: req.session.user});
});

router.get('/subirDA',(req, res)=> {
    res.render('personas/admin/subirD');
});

router.get('/subirD',(req, res)=> {
    res.render('personas/alumno/subirD');
});

router.get('/busquedaSA',(req, res)=> {
    res.render('personas/alumno/busquedaS', { user: req.session.user });
});

router.get('/misTrabajos',(req, res)=> {
    res.render('personas/docente/misTrabajos', { user: req.session.user });
});

router.get('/miPropuesta/:name', async(req,res)=>{
    const {name} = req.params;
    console.log(name);
    try{
        const [result] = await pool.query('SELECT * FROM propuestasAceptadas WHERE autores LIKE ?', [`%${name}%`]);

        console.log(result);
        res.render('personas/alumno/miPropuesta', {propuestas: result, user: req.session.user });
    }catch(err){
        res.status(500).json({message:err.message});
    }
});

router.get('/misTrabajos/:id', async (req, res) => {
    const { id } = req.params;
    
    try {
        const [result] = await pool.query(`
            SELECT pa.*
            FROM propuestasAceptadas pa
            JOIN misTrabajos mt ON pa.id = mt.idP
            JOIN personas p ON mt.idD = p.id
            WHERE p.id = ?;
        `, [id]);
        
        console.log(result);
        res.render('personas/docente/misTrabajos', { propuestas: result, user: req.session.user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: err.message });
    }
});

router.get('/busquedaSad',(req, res)=> {
    res.render('personas/admin/busquedaS', { user: req.session.user });
});

router.get('/busquedaSD',(req, res)=> {
    res.render('personas/docente/busquedaS', { user: req.session.user });
});



router.post('/add', async(req, res) => {
    try{
        const {name, lastname, age,email,pass,tipo} = req.body;
        const newPersona = {
            name, lastname,age,email,pass,tipo
        }
        await pool.query('insert into personas SET ?', [newPersona]);
        res.redirect('/list');
    }catch(err){
        res.status(500).json({message:err.message});
    }
});

router.post('/enviarPropuesta', async(req, res) => {
    try{
        const {titulo, autores,directores,resumen} = req.body;
        const newPropuesta = {
            titulo, autores,directores,resumen
        }
        console.log(newPropuesta);
        await pool.query('insert into propuestas SET ?', [newPropuesta]);
        res.redirect('/homeAlumno');
    }catch(err){
        res.status(500).json({message:err.message});
    }
});

router.get('/files', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM pdf_files');
        console.log(rows);
        res.render('personas/files', {archivos: rows});
    } catch (error) {
        console.error(error);
        res.status(500).send('Error al obtener la lista de archivos.');
    }
});

router.get('/list', async(req,res)=>{
    try{
        const [result]= await pool.query('select * from personas');
        console.log(result);
        res.render('personas/list', {personas: result});
    }catch(err){
        res.status(500).json({message:err.message});
    }
});

router.get('/verPropuestas', async(req,res)=>{
    try{
        const [result]= await pool.query('select * from propuestas');
        console.log(result);
        res.render('personas/admin/verPropuestas', {propuestas: result});
    }catch(err){
        res.status(500).json({message:err.message});
    }
});



router.get('/aceptar/:id', async (req, res) => {
    const { id } = req.params;
    console.log(id);
    try {
        const [result] = await pool.query('SELECT * FROM propuestas WHERE id = ?', [id]);
        if (result.length > 0) {
            console.log(result[0].autores);
            const titulo = result[0].titulo;
            const autores = result[0].autores;
            const directores = result[0].directores;
            const resumen = result[0].resumen;
            const sinodal = "";
            const newPropuesta = {
                titulo, autores, directores, resumen, sinodal
            }
            console.log(newPropuesta);
            await pool.query('INSERT INTO propuestasAceptadas SET ?', [newPropuesta]);
            await pool.query('DELETE FROM propuestas WHERE id = ?', [id]);
            res.redirect(`/asignarSinodal`);
        } else {
            res.status(404).send('Propuesta no encontrada.');
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.post('/docenteAsignado/:id', async (req, res) => {
    const { sinodalA } = req.body;
    const { id } = req.params;
    console.log(sinodalA);
    try {
        const [result] = await pool.query('SELECT * FROM propuestasAceptadas WHERE id = ?', [id]);
        if (result.length > 0) {
            console.log(result[0].autores);
            const titulo = result[0].titulo;
            const autores = result[0].autores;
            const directores = result[0].directores;
            const resumen = result[0].resumen;
            const sinodal = sinodalA;
            const newPropuesta = {
                titulo, autores, directores, resumen, sinodal
            };
            console.log(newPropuesta);
            
            await pool.query('UPDATE propuestasAceptadas SET sinodal = ? WHERE id = ?', [sinodal, id]);
            const [IdDocente] = await pool.query('SELECT id FROM personas WHERE name = ?', [sinodal]);
            const idD = IdDocente[0].id;
            const idP = id;
            console.log(typeof idD);
            console.log(typeof idP);
            const misT = {
                idP, idD
            }
            await pool.query('INSERT INTO misTrabajos SET ?', [misT]);
            res.redirect(`/homeAdmin`);
        } else {
            res.status(404).send('Propuesta no encontrada.');
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.get('/buscar', async (req, res) => {
    const { ano, titulo, autor, campo } = req.query;
    const user = req.session.user ;
    try {
        const query = `
            SELECT * FROM trabajos_titulacion
            WHERE
                (ano = ? OR ? IS NULL)
                AND (titulo LIKE CONCAT('%', ?, '%') OR ? IS NULL)
                AND (autores LIKE CONCAT('%', ?, '%') OR ? IS NULL)
                AND (campo_de_estudio = ? OR ? IS NULL)
        `;

        const [result] = await pool.query(query, [
            ano || null, ano || null,
            titulo || null, titulo || null,
            autor || null, autor || null,
            campo || null, campo || null
        ]);
        
        res.render('personas/resultados', { trabajos: result, user: user });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.get('/aprobado/:id', async (req, res) => {
    const { id } = req.params;
    const aprobado  = 'aprobado';
    console.log(id);
    console.log(aprobado);
    console.log(id);
    try {
        const [result] = await pool.query('SELECT * FROM propuestasAceptadas WHERE id = ?', [id]);
        console.log(result);
        if (result.length > 0) {
            await pool.query('UPDATE propuestasAceptadas SET aprobado = ? WHERE id = ?', [aprobado,id]);
            
            res.redirect(`/homeDocente`);
        } else {
            res.status(404).send('Propuesta no encontrada.');
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

export default router;