import express from 'express';
import multer from 'multer';
import { engine } from 'express-handlebars';
import morgan from 'morgan';
import { join, dirname } from 'path'; // Importa join y dirname de path
import { fileURLToPath } from 'url';
import session from 'express-session';
import personasroutes from './routes/personas.routes.js';
import authRoutes from './routes/auth.routes.js';  // Importar las rutas de autenticación
import pool from './database.js'

// Inicialización
const app = express();
const __dirname = dirname(fileURLToPath(import.meta.url));

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}-${file.originalname}`);
    }
});

const upload = multer({ storage: storage });

// Configuración de vistas
app.set('views', join(__dirname, 'views'));

// Configuración de Handlebars
app.engine('.hbs', engine({
    defaultLayout: 'main',
    layoutsDir: join(app.get('views'), 'layouts'),
    partialsDir: join(app.get('views'), 'partials'),
    extname: '.hbs'
}));
app.set('view engine', '.hbs');

// Middleware
app.use(morgan('dev'));
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: true
}));

// Rutas
app.get('/', (req, res) => {
    res.render('index');
});
app.use(personasroutes);
app.use(authRoutes);  // Usar las rutas de autenticación

// Archivos públicos
app.use(express.static(join(__dirname, 'public')));


// Iniciar el servidor
app.set('port', process.env.PORT || 3000);
app.listen(app.get('port'), () => {
    console.log('Server listening on port', app.get('port'));
});

app.post('/uploadAlumno', upload.single('archivo'), async (req, res) => {
    const { file } = req;
    const { titulo, autores, director_tesis, resumen, abstract, referencias, notas, campo_de_estudio, ano, mes } = req.body;

    if (!file) {
        return res.status(400).send('No se ha subido ningún archivo.');
    }

    const filePath = join('D:/Escuela/6to Semestre/ISW/final/Aeneta/uploads', file.filename); // Usa join para construir la ruta del archivo

    try {
        // Insertar los datos del formulario y la ruta del archivo en la base de datos
        const [result] = await pool.query(
            `INSERT INTO trabajos_titulacion 
            (titulo, autores, director_tesis, resumen, abstract, referencias, notas, campo_de_estudio, ano, mes, url) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [titulo, autores, director_tesis, resumen, abstract, referencias, notas, campo_de_estudio, ano, mes, filePath]
        );

        // Renderizar la vista de éxito
        res.render('personas/homeAlumno', { 
            user: req.session.user,
            message: 'Trabajo de titulación subido y guardado en la base de datos correctamente.' // Pasar el mensaje de éxito a la vista
        });
    } catch (error) {
        console.error(error);
        // Renderizar la vista de error
        res.render('personas/homeAlumno', {
            user: req.session.user,
            error: 'Error al guardar el trabajo de titulación en la base de datos.' // Pasar el mensaje de error a la vista
        });
    }
});

app.post('/upload', upload.single('archivo'), async (req, res) => {
    const { file } = req;
    const { titulo, autores, director_tesis, resumen, abstract, referencias, notas, campo_de_estudio, ano, mes } = req.body;

    if (!file) {
        return res.status(400).send('No se ha subido ningún archivo.');
    }

    const filePath = join('D:/Escuela/6to Semestre/ISW/final/Aeneta/uploads', file.filename); // Usa join para construir la ruta del archivo

    try {
        // Insertar los datos del formulario y la ruta del archivo en la base de datos
        const [result] = await pool.query(
            `INSERT INTO trabajos_titulacion 
            (titulo, autores, director_tesis, resumen, abstract, referencias, notas, campo_de_estudio, ano, mes, url) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [titulo, autores, director_tesis, resumen, abstract, referencias, notas, campo_de_estudio, ano, mes, filePath]
        );

        // Renderizar la vista de éxito
        res.render('personas/homeAdmin', { 
            user: req.session.user,
            message: 'Trabajo de titulación subido y guardado en la base de datos correctamente.' // Pasar el mensaje de éxito a la vista
        });
    } catch (error) {
        console.error(error);
        // Renderizar la vista de error
        res.render('personas/homeAdmin', {
            user: req.session.user,
            error: 'Error al guardar el trabajo de titulación en la base de datos.' // Pasar el mensaje de error a la vista
        });
    }
});

// Ruta para obtener la lista de archivos


// Ruta para servir el archivo PDF
app.get('/files/:id', async (req, res) => {
    const { id } = req.params;
    console.log(id);
    try {
        const [rows] = await pool.query('SELECT * FROM trabajos_titulacion WHERE id = ?', [id]);
        console.log(rows[0]);
        if (rows.length > 0) {
            const filePath = rows[0].url;
            console.log(filePath);
            res.sendFile(filePath);
        } else {
            res.status(404).send('Archivo no encontrado.');
        }
    } catch (error) {
        console.error(error);
        res.status(500).send('Error al obtener el archivo.');
    }
});
