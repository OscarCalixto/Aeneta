-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: aenetabd
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `trabajos_titulacion`
--

DROP TABLE IF EXISTS `trabajos_titulacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trabajos_titulacion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) NOT NULL,
  `autores` varchar(255) NOT NULL,
  `director_tesis` varchar(255) DEFAULT NULL,
  `resumen` text,
  `abstract` text,
  `referencias` text,
  `notas` text,
  `url` varchar(255) DEFAULT NULL,
  `campo_de_estudio` varchar(100) DEFAULT NULL,
  `ano` int DEFAULT NULL,
  `mes` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trabajos_titulacion`
--

LOCK TABLES `trabajos_titulacion` WRITE;
/*!40000 ALTER TABLE `trabajos_titulacion` DISABLE KEYS */;
INSERT INTO `trabajos_titulacion` VALUES (1,'Análisis de Algoritmos de Machine Learning','Juan Pérez, María García','Dr. Carlos Sánchez','Este trabajo explora diferentes algoritmos de machine learning y evalúa su rendimiento en varios conjuntos de datos.','Analysis of Machine Learning Algorithms','Smith, J., & Johnson, A. (2020). Machine Learning Techniques. Journal of Machine Learning Research.','Presentado en la conferencia XYZ 2023.','https://example.com/trabajo1','Inteligencia Artificial',2023,5),(2,'Estudio de la Sostenibilidad en Energías Renovables','Pedro Martínez, Laura Gómez','Dra. Ana Fernández','Investigación sobre la sostenibilidad y el impacto ambiental de las energías renovables en la actualidad.','Study of Sustainability in Renewable Energies','Green, T., & Brown, E. (2021). Renewable Energy and Sustainability. Environmental Science Journal.','Premiado como mejor trabajo de titulación en 2022.','https://example.com/trabajo2','Ingeniería Ambiental',2022,12),(3,'Desarrollo de Aplicaciones Web Seguras','Carlos López','Mtra. Diana Ramírez','Desarrollo de técnicas y metodologías para asegurar la seguridad en aplicaciones web modernas.','Development of Secure Web Applications','White, L., & Black, M. (2019). Web Application Security. Security Journal.','Presentado en la conferencia de Seguridad Informática 2021.','https://example.com/trabajo3','Seguridad Informática',2021,8),(4,'Diseño de un Sistema de Gestión de Inventarios','María Fernández, Javier Ramírez','Dr. Pablo Torres','Este trabajo presenta el diseño y la implementación de un sistema de gestión de inventarios para pequeñas empresas.','Design of an Inventory Management System','Green, T., & Brown, E. (2022). Inventory Management Systems. Business Technology Journal.','Presentado en la conferencia de Ingeniería de Software 2024.','https://example.com/trabajo4','Ingeniería de Software',2024,4),(5,'Impacto de las Redes Sociales en el Comportamiento del Consumidor','Ana Rodríguez','Dra. Laura Martínez','Estudio sobre cómo las redes sociales influyen en las decisiones de compra de los consumidores en la actualidad.','Impact of Social Media on Consumer Behavior','Smith, J., & Johnson, A. (2023). Social Media and Consumer Behavior. Marketing Science Review.','Premiado como mejor investigación de mercados en 2023.','https://example.com/trabajo5','Marketing',2023,10),(6,'Desarrollo de un Sistema de Recomendación Personalizado','Carlos Pérez','Dr. Juan Soto','Investigación sobre el desarrollo de algoritmos para sistemas de recomendación personalizados en plataformas de comercio electrónico.','Development of a Personalized Recommendation System','White, L., & Black, M. (2021). Recommendation Systems. AI Journal.','Presentado en la conferencia de Inteligencia Artificial 2022.','https://example.com/trabajo6','Inteligencia Artificial',2022,6),(7,'Análisis de la Eficiencia Energética en Edificios Sostenibles','Elena Gómez, David Hernández','Dra. Ana García','Estudio de la eficiencia energética y el impacto ambiental en edificios sostenibles utilizando simulaciones y análisis de datos.','Analysis of Energy Efficiency in Sustainable Buildings','Brown, M., & Green, L. (2020). Energy Efficiency in Buildings. Sustainable Development Journal.','Proyecto de investigación financiado por la UNESCO.','https://example.com/trabajo7','Ingeniería Civil',2021,2),(8,'Desarrollo de Aplicaciones Móviles para la Salud Mental','Laura Martín','Mtro. Luis Méndez','Desarrollo de aplicaciones móviles para la gestión y el seguimiento de la salud mental de los usuarios.','Development of Mobile Applications for Mental Health','Martinez, E., & Rodriguez, S. (2019). Mobile Health Applications. Health Technology Review.','Presentado en la conferencia de Salud Digital 2020.','https://example.com/trabajo8','Salud Digital',2020,9),(9,'Impacto del Cambio Climático en la Agricultura','Roberto López','Dr. José Torres','Estudio sobre cómo el cambio climático está afectando la productividad agrícola y las estrategias de adaptación necesarias.','Impact of Climate Change on Agriculture','Gomez, R., & Martinez, P. (2018). Climate Change and Agriculture. Environmental Science Journal.','Investigación financiada por el Banco Mundial.','https://example.com/trabajo9','Agronomía',2019,7),(10,'Desarrollo de Sistemas de Control de Tráfico Inteligente','Javier González','Dr. Pedro García','Desarrollo de sistemas avanzados de control de tráfico utilizando tecnologías IoT y análisis de big data.','Development of Intelligent Traffic Control Systems','Garcia, P., & Sanchez, L. (2017). Intelligent Transportation Systems. Transportation Research.','Proyecto de colaboración con el gobierno local.','https://example.com/trabajo10','Ingeniería Electrónica',2018,11),(11,'Nuevo Titulo','bueo','awdawa','wdawd','awdawd','awdaw','adw','D:\\Escuela\\6to Semestre\\ISW\\final\\Aeneta\\uploads\\1719183397916-comprobanteVigenciaDerechos38170379705.pdf','daw',2012,1),(12,'otro jijij','jij','i','ji','j','ij','ij','D:\\Escuela\\6to Semestre\\ISW\\final\\Aeneta\\uploads\\1719183815049-SEGUROS.pdf','i',1,1),(13,'dawda','dawd','awdaw','dawdaw','dawdawd','awdawdaw','dawd','D:\\Escuela\\6to Semestre\\ISW\\final\\Aeneta\\uploads\\1719184629453-ManualHistologÃ­aDra2 ðð» (1).pdf','dawdawd',2022,22),(14,'2222','222','22','222','222','22','222','D:\\Escuela\\6to Semestre\\ISW\\final\\Aeneta\\uploads\\1719184751021-Practica 13 Aparato Digestivo.pdf','222',22,22),(15,'wda','wdawd','awdawdaw','dawdawda','wdawd','awdaw','awda','D:\\Escuela\\6to Semestre\\ISW\\final\\Aeneta\\uploads\\1719187539913-HIPHOP.pdf','awd',2,2);
/*!40000 ALTER TABLE `trabajos_titulacion` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-23 22:44:11
