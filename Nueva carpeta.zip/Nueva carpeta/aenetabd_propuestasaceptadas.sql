-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: aenetabd
-- ------------------------------------------------------
-- Server version	8.0.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `propuestasaceptadas`
--

DROP TABLE IF EXISTS `propuestasaceptadas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `propuestasaceptadas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `titulo` varchar(50) NOT NULL,
  `autores` varchar(150) NOT NULL,
  `directores` varchar(150) DEFAULT NULL,
  `resumen` varchar(250) NOT NULL,
  `sinodal` varchar(250) DEFAULT NULL,
  `aprobado` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `propuestasaceptadas`
--

LOCK TABLES `propuestasaceptadas` WRITE;
/*!40000 ALTER TABLE `propuestasaceptadas` DISABLE KEYS */;
INSERT INTO `propuestasaceptadas` VALUES (1,'ejemplo','ejemplo','ejemplo','ejemplo','Juan','aprobado'),(2,'1','1','1','1','Juan',NULL),(3,'1','1','1','1','',NULL),(4,'1','1','1','1','',NULL),(5,'1','1','1','1','',NULL),(6,'1','1','1','1','',NULL),(7,'1','1','1','1','',NULL),(8,'1','1','1','1','Juan',NULL),(9,'ejemplo','ejemplo','ejemplo','ejemplo','',NULL),(10,'ejemplo','ejemplo','ejemplo','ejemplo','',NULL),(11,'1','1','1','1','',NULL),(12,'ejemplo','ejemplo','ejemplo','ejemplo','',NULL),(13,'1','1','1','1','',NULL),(14,'1','1','1','1','',NULL),(15,'1','1','1','1','',NULL),(16,'1','1','1','1','',NULL),(17,'1','1','1','1','',NULL),(18,'1','1','1','1','',NULL),(19,'1','1','1','1','',NULL),(20,'ejemplo','ejemplo','ejemplo','ejemplo','',NULL),(21,'1','1','1','1','',NULL),(22,'1','1','1','1','',NULL),(23,'ejemplo','ejemplo','ejemplo','ejemplo','',NULL),(24,'1','1','1','1','',NULL),(25,'ejemplo','ejemplo','ejemplo','ejemplo','',NULL),(26,'ejemplo','ejemplo','ejemplo','ejemplo','',NULL),(27,'1','1','1','1','',NULL),(28,'ejemplo','ejemplo','ejemplo','ejemplo','Juan',NULL),(29,'ejemplo','ejemplo','ejemplo','ejemplo','sinodal2',NULL),(30,'ejemplo','ejemplo','ejemplo','ejemplo','Dra. María González',NULL),(31,'NuevaPropuesta','Oscar Calixto','Bernabé Rocha','Texto de resumen','Juan','aprobado'),(32,'Nuevo Titulo','Oscar Calixto','Bernabé Rocha','Texto de resumen 2','Juan','aprobado'),(33,'Ultima propuesta','Oscar Calixto','Luz Calixto','AWJHDWUIBDAWIBDWUIAHBDUAY','Juan','aprobado'),(34,'Machine Learning','Isis Valeria Leyva Triana','Bernabé Rocha','Ejemplo de resumen','Juan','aprobado');
/*!40000 ALTER TABLE `propuestasaceptadas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-23 22:44:11
