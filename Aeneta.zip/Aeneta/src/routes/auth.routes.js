// auth.routes.js

import { Router } from 'express';
import pool from '../database.js'; // Importa la configuración de conexión a la base de datos

const router = Router();

// Ruta para el formulario de login
router.get('/login', (req, res) => {
    res.render('index'); // Renderiza 'index.hbs' en lugar de 'login.hbs'
});

router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        // Consulta SQL para verificar el usuario y contraseña
        const sql = 'SELECT * FROM personas WHERE email = ? AND pass = ?';
        const [rows, fields] = await pool.execute(sql, [email, password]);

        if (rows.length > 0) {
            const user = rows[0];
            req.session.user = user;

            // Redirige según el tipo de usuario
            if (user.tipo === 'admin') {
                res.redirect('/homeAdmin');
            } else if (user.tipo === 'alumno') {
                res.redirect('/homeAlumno');
            } else if (user.tipo === 'docente') {
                res.redirect('/homeDocente');
            } else {
                res.send('<script>alert("Tipo de usuario desconocido"); window.location.href="/";</script>');
            }
        } else {
            res.send('<script>alert("Correo o contraseña incorrectos"); window.location.href="/";</script>');
        }
    } catch (error) {
        console.error('Error al ejecutar la consulta:', error);
        res.send('<script>alert("Error de autenticación"); window.location.href="/";</script>');
    }
});

// Ruta para la página de home del alumno
router.get('/homeAlumno', (req, res) => {
    if (req.session.user && req.session.user.tipo === 'alumno') {
        res.render('personas/homeAlumno', { user: req.session.user });
    } else {
        res.redirect('/');
    }
});

// Ruta para la página de dashboard del admin
router.get('/homeAdmin', (req, res) => {
    if (req.session.user && req.session.user.tipo === 'admin') {
        res.render('personas/homeAdmin', { user: req.session.user });
    } else {
        res.redirect('/');
    }
});

// Ruta para la página de dashboard del docente
router.get('/homeDocente', (req, res) => {
    if (req.session.user && req.session.user.tipo === 'docente') {
        res.render('personas/homeDocente', { user: req.session.user });
    } else {
        res.redirect('/');
    }
});

// Ruta para cerrar sesión
router.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/');
});

export default router;
