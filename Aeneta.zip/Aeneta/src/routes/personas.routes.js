import {Router} from 'express'
import pool from '../database.js'

const router = Router();

router.get('/add',(req, res)=> {
    res.render('personas/add');
});

router.get('/busquedaS',(req, res)=> {
    res.render('personas/alumno/busquedaS', { user: req.session.user });
});



router.post('/add', async(req, res) => {
    try{
        const {name, lastname, age,email,pass} = req.body;
        const newPersona = {
            name, lastname,age,email,pass
        }
        await pool.query('insert into personas SET ?', [newPersona]);
        res.redirect('/list');
    }catch(err){
        res.status(500).json({message:err.message});
    }
});



router.get('/list', async(req,res)=>{
    try{
        const [result]= await pool.query('select * from personas');
        res.render('personas/list', {personas: result});
    }catch(err){
        res.status(500).json({message:err.message});
    }
});

export default router;