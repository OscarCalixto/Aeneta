CREATE DATABASE Prueba01;

Use Prueba01;

CREATE table personas(
    id INT auto_increment primary key,
    name varchar(50) not null,
    lastname varchar(50) not null,
    age int
);

select * from personas;