create database AenetaBD;

use AenetaBD;

create table personas(
    id INT auto_increment primary key,
    name varchar(50) not null,
    lastname varchar(50) not null,
    age int,
    email varchar(50) not null,
    pass varchar(50) not null
);

ALTER TABLE personas
ADD COLUMN tipo ENUM('admin', 'alumno', 'docente') NOT NULL DEFAULT 'alumno';

CREATE TABLE trabajos_titulacion (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    autores VARCHAR(255) NOT NULL,
    director_tesis VARCHAR(255),
    resumen TEXT,
    abstract TEXT,
    referencias TEXT,
    notas TEXT,
    url VARCHAR(255),
    campo_de_estudio VARCHAR(100),
    ano INT,
    mes INT
);


INSERT INTO trabajos_titulacion (titulo, autores, director_tesis, resumen, abstract, referencias, notas, url, campo_de_estudio, ano, mes)
VALUES
    ('Análisis de Algoritmos de Machine Learning', 'Juan Pérez, María García', 'Dr. Carlos Sánchez', 'Este trabajo explora diferentes algoritmos de machine learning y evalúa su rendimiento en varios conjuntos de datos.', 'Analysis of Machine Learning Algorithms', 'Smith, J., & Johnson, A. (2020). Machine Learning Techniques. Journal of Machine Learning Research.', 'Presentado en la conferencia XYZ 2023.', 'https://example.com/trabajo1', 'Inteligencia Artificial', 2023, 5),
    ('Estudio de la Sostenibilidad en Energías Renovables', 'Pedro Martínez, Laura Gómez', 'Dra. Ana Fernández', 'Investigación sobre la sostenibilidad y el impacto ambiental de las energías renovables en la actualidad.', 'Study of Sustainability in Renewable Energies', 'Green, T., & Brown, E. (2021). Renewable Energy and Sustainability. Environmental Science Journal.', 'Premiado como mejor trabajo de titulación en 2022.', 'https://example.com/trabajo2', 'Ingeniería Ambiental', 2022, 12),
    ('Desarrollo de Aplicaciones Web Seguras', 'Carlos López', 'Mtra. Diana Ramírez', 'Desarrollo de técnicas y metodologías para asegurar la seguridad en aplicaciones web modernas.', 'Development of Secure Web Applications', 'White, L., & Black, M. (2019). Web Application Security. Security Journal.', 'Presentado en la conferencia de Seguridad Informática 2021.', 'https://example.com/trabajo3', 'Seguridad Informática', 2021, 8);

INSERT INTO trabajos_titulacion (titulo, autores, director_tesis, resumen, abstract, referencias, notas, url, campo_de_estudio, ano, mes)
VALUES
    ('Diseño de un Sistema de Gestión de Inventarios', 'María Fernández, Javier Ramírez', 'Dr. Pablo Torres', 'Este trabajo presenta el diseño y la implementación de un sistema de gestión de inventarios para pequeñas empresas.', 'Design of an Inventory Management System', 'Green, T., & Brown, E. (2022). Inventory Management Systems. Business Technology Journal.', 'Presentado en la conferencia de Ingeniería de Software 2024.', 'https://example.com/trabajo4', 'Ingeniería de Software', 2024, 4),
    ('Impacto de las Redes Sociales en el Comportamiento del Consumidor', 'Ana Rodríguez', 'Dra. Laura Martínez', 'Estudio sobre cómo las redes sociales influyen en las decisiones de compra de los consumidores en la actualidad.', 'Impact of Social Media on Consumer Behavior', 'Smith, J., & Johnson, A. (2023). Social Media and Consumer Behavior. Marketing Science Review.', 'Premiado como mejor investigación de mercados en 2023.', 'https://example.com/trabajo5', 'Marketing', 2023, 10),
    ('Desarrollo de un Sistema de Recomendación Personalizado', 'Carlos Pérez', 'Dr. Juan Soto', 'Investigación sobre el desarrollo de algoritmos para sistemas de recomendación personalizados en plataformas de comercio electrónico.', 'Development of a Personalized Recommendation System', 'White, L., & Black, M. (2021). Recommendation Systems. AI Journal.', 'Presentado en la conferencia de Inteligencia Artificial 2022.', 'https://example.com/trabajo6', 'Inteligencia Artificial', 2022, 6),
    ('Análisis de la Eficiencia Energética en Edificios Sostenibles', 'Elena Gómez, David Hernández', 'Dra. Ana García', 'Estudio de la eficiencia energética y el impacto ambiental en edificios sostenibles utilizando simulaciones y análisis de datos.', 'Analysis of Energy Efficiency in Sustainable Buildings', 'Brown, M., & Green, L. (2020). Energy Efficiency in Buildings. Sustainable Development Journal.', 'Proyecto de investigación financiado por la UNESCO.', 'https://example.com/trabajo7', 'Ingeniería Civil', 2021, 2),
    ('Desarrollo de Aplicaciones Móviles para la Salud Mental', 'Laura Martín', 'Mtro. Luis Méndez', 'Desarrollo de aplicaciones móviles para la gestión y el seguimiento de la salud mental de los usuarios.', 'Development of Mobile Applications for Mental Health', 'Martinez, E., & Rodriguez, S. (2019). Mobile Health Applications. Health Technology Review.', 'Presentado en la conferencia de Salud Digital 2020.', 'https://example.com/trabajo8', 'Salud Digital', 2020, 9),
    ('Impacto del Cambio Climático en la Agricultura', 'Roberto López', 'Dr. José Torres', 'Estudio sobre cómo el cambio climático está afectando la productividad agrícola y las estrategias de adaptación necesarias.', 'Impact of Climate Change on Agriculture', 'Gomez, R., & Martinez, P. (2018). Climate Change and Agriculture. Environmental Science Journal.', 'Investigación financiada por el Banco Mundial.', 'https://example.com/trabajo9', 'Agronomía', 2019, 7),
    ('Desarrollo de Sistemas de Control de Tráfico Inteligente', 'Javier González', 'Dr. Pedro García', 'Desarrollo de sistemas avanzados de control de tráfico utilizando tecnologías IoT y análisis de big data.', 'Development of Intelligent Traffic Control Systems', 'Garcia, P., & Sanchez, L. (2017). Intelligent Transportation Systems. Transportation Research.', 'Proyecto de colaboración con el gobierno local.', 'https://example.com/trabajo10', 'Ingeniería Electrónica', 2018, 11);



select * from personas;